package com.example.project360;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private TextView smsPermissionStatus;
    private Button requestSmsPermissionButton, addDataButton, editDataButton, deleteDataButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI Elements
        smsPermissionStatus = findViewById(R.id.smsPermissionStatus);
        requestSmsPermissionButton = findViewById(R.id.requestSmsPermissionButton);
        addDataButton = findViewById(R.id.addDataButton);
        editDataButton = findViewById(R.id.addDataButton2);
        deleteDataButton = findViewById(R.id.addDataButton3);

        // Check and update SMS Permission Status
        updateSmsPermissionStatus();

        // Request SMS Permission
        requestSmsPermissionButton.setOnClickListener(view -> requestSmsPermission());

        // Button Listeners
        addDataButton.setOnClickListener(view -> addData());
        editDataButton.setOnClickListener(view -> editData());
        deleteDataButton.setOnClickListener(view -> deleteData());
    }

    private void updateSmsPermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            smsPermissionStatus.setText("Notification Status: Enabled");
        } else {
            smsPermissionStatus.setText("Notification Status: Disabled");
        }
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            Toast.makeText(this, "SMS Permission Already Granted!", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the Permission Request Result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted!", Toast.LENGTH_SHORT).show();
                updateSmsPermissionStatus();
            } else {
                Toast.makeText(this, "SMS Permission Denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void addData() {
        // Simulated function for adding data
        Toast.makeText(this, "Data Added", Toast.LENGTH_SHORT).show();
    }

    private void editData() {
        // Simulated function for editing data
        Toast.makeText(this, "Data Edited", Toast.LENGTH_SHORT).show();
    }

    private void deleteData() {
        // Simulated function for deleting data
        Toast.makeText(this, "Data Deleted", Toast.LENGTH_SHORT).show();

        // If stock is low, send an SMS notification
        sendLowStockSMS();
    }

    private void sendLowStockSMS() {
        String phoneNumber = "1234567890"; // Replace with actual recipient's number
        String message = "Warning: Stock is low!";

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Low Stock SMS Sent!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS Permission Not Granted!", Toast.LENGTH_SHORT).show();
        }
    }
}
