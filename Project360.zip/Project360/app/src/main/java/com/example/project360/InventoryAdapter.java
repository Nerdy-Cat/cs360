package com.example.project360;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {
    private List<InventoryItem> inventoryList;

    public InventoryAdapter(List<InventoryItem> inventoryList) {
        this.inventoryList = inventoryList;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.inventory_item, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = inventoryList.get(position);
        holder.name.setText(item.getName());
        holder.description.setText(item.getDescription());
        holder.stock.setText("Stock: " + item.getStock());
        holder.lastUpdated.setText("Updated: " + item.getLastUpdated());
    }

    @Override
    public int getItemCount() {
        return inventoryList.size();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView name, description, stock, lastUpdated;

        public InventoryViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.itemName);
            description = view.findViewById(R.id.itemDescription);
            stock = view.findViewById(R.id.itemStock);
            lastUpdated = view.findViewById(R.id.itemLastUpdated);
        }
    }
}
