package com.example.project360;

public class InventoryItem {
    private String name;
    private String description;
    private int stock;
    private String lastUpdated;

    public InventoryItem(String name, String description, int stock, String lastUpdated) {
        this.name = name;
        this.description = description;
        this.stock = stock;
        this.lastUpdated = lastUpdated;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getStock() { return stock; }
    public String getLastUpdated() { return lastUpdated; }
}
