package com.example.project360;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    EditText phoneInput, passwordInput;
    Button submitButton, newAccountButton;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        phoneInput = findViewById(R.id.editTextPhone);
        passwordInput = findViewById(R.id.editTextTextPassword2);
        submitButton = findViewById(R.id.button2);
        newAccountButton = findViewById(R.id.button);

        sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = phoneInput.getText().toString();
                String password = passwordInput.getText().toString();

                String savedPhone = sharedPreferences.getString("phone", "");
                String savedPassword = sharedPreferences.getString("password", "");

                if (phone.equals(savedPhone) && password.equals(savedPassword)) {
                    Toast.makeText(Login.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Login.this, MainActivity.class));
                    finish();
                } else {
                    Toast.makeText(Login.this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        newAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("phone", phoneInput.getText().toString());
                editor.putString("password", passwordInput.getText().toString());
                editor.apply();

                Toast.makeText(Login.this, "Account Created!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
